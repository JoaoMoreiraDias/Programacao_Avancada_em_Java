package bd;

//
// execut�vel (tem main)
// teste do c�digo
// ao ser executado, altera a base de dados
// para repor os dados iniciais, voltar a executar criaBD
//
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Teste {

	public Teste() {
	}

	public static void main(String[] args) {
		Connection derby;
		Statement st;
		String q;
		Aluno a = null;
		Turma t = null;
		System.out.println("get connection");
		derby = LigacaoBD.getConnection();
		//
		System.out.println("tabela Aluno");
		ArrayList<Aluno> alunos = new ArrayList<Aluno>();
		alunos = Aluno.getAlunos(); // todos os alunos
		for (Aluno al : alunos)
			System.out.println(al);
		System.out.println("------------------------------");
		//
		System.out.println("tabela Turma");
		ArrayList<Turma> turmas = new ArrayList<Turma>();
		turmas = Turma.getTurmas(); // todas as turmas
		for (Turma tu : turmas)
			System.out.println(tu);
		System.out.println("------------------------------");
		//
		// um exemplo misturando SQL no c�digo Java. � muito mais complicado de
		// ler
		//
		System.out.println("tabela Aluno Turma");
		st = null;
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out
					.println(" Erro ao criar o 'statement' da base de dados ");
			return;
		}
		q = "SELECT * FROM AlunoTurma";
		try {
			ResultSet res = st.executeQuery(q);
			while (res.next()) { // teve resposta ?
				System.out.println(res.getInt("idAluno") + "  "
						+ res.getInt("idTurma"));
			}
			res.close();
			st.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao fazer query " + st);
			return;
		}
		//
		System.out.println("--------------------------------");
		System.out.println("Juntando turma 1 ao aluno 4:");
		a = Aluno.getAlunoId(4);
		if (a != null) {
			t = Turma.getTurmaNum(1);
			if (t != null) {
				a.juntaTurma(t);
			}
			a.grava();
		}
		a = Aluno.getAlunoNum(4);
		if (a != null) {
			System.out.println(a);
		}
		System.out.println("--------------------------------");
		System.out.println("Apagando turma 11 do aluno 4:");
		a = Aluno.getAlunoId(4);
		if (a != null) {
			t = Turma.getTurmaNum(11);
			if (t != null) {
				a.apagaTurma(t);
			}
			a.grava();
		}
		a = Aluno.getAlunoNum(4);
		System.out.println(a);
		System.out.println("--------------------------------");
		System.out
				.println("Apagando aluno 3 e escrevendo a tabela de alunos e alunos/turmas:");
		a = Aluno.getAlunoId(3);
		if (a != null)
			a.apaga();
		//
		System.out.println("tabela Aluno");
		alunos = new ArrayList<Aluno>();
		alunos = Aluno.getAlunos(); // todos os alunos
		for (Aluno al : alunos)
			System.out.println(al);
		System.out.println("------------------------------");
		//
		// repetindo o exemplo misturando SQL no c�digo Java. � muito mais
		// complicado de ler
		//
		System.out.println("tabela Aluno Turma");
		st = null;
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out
					.println(" Erro ao criar o 'statement' da base de dados ");
			return;
		}
		q = "SELECT * FROM AlunoTurma";
		try {
			ResultSet res = st.executeQuery(q);
			while (res.next()) { // teve resposta ?
				System.out.println(res.getInt("idAluno") + "  "
						+ res.getInt("idTurma"));
			}
			res.close();
			st.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao fazer query " + st);
			return;
		}

		System.out.println("terminei!!!");

		LigacaoBD.close();
	}

}
