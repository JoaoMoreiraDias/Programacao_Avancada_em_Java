package bd;
//
// execut�vel (tem main)
// cria a base de dados e tabelas
// preenche as tabelas com dados iniciais para teste
//
import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class CriaBD {
	Connection derby;

	public CriaBD() {
		System.out.println("get connection");
		derby = LigacaoBD.getConnection();
		//
		criaTabelas();
		System.out.println();
		System.out.println("terminei!!!");
		LigacaoBD.close();
	}

	protected void commit(String descr) {
		String q;
		Statement st = null;
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out
					.println(" Erro ao criar o 'statement' da base de dados para COMMIT "
							+ " Curso - " + descr + " ");
			return;
		}
		try {
			q = "COMMIT";
			st.execute(q);
		} catch (Exception em) {
			em.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao executar COMMIT " + " Curso - "
					+ descr + " ");
		}
		if (st != null) {
			try {
				st.close();
			} catch (Exception em) {
				em.printStackTrace();
			}
		}
	}

	private void criaTabelas() {
		String q = "";
		Statement st = null;
		System.out.println("Cria��o do statement");
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao criar 'statement' " + " CreateBD ");
			System.out.println(ex.getMessage());
			System.exit(1);
		}
		System.out.println("Cria��o das tabelas\n");
		//
		// Aluno
		//
		System.out.println("Cria��o da tabela Aluno");
		try {
			q = "DROP TABLE AlunoTurma";
			st.execute(q);
			q = "DROP TABLE Aluno";
			st.execute(q);
			q = "DROP TABLE Turma";
			st.execute(q);
		} catch (Exception e) {
			System.out.println();
			System.out.println(" Erro ao apagar tabela Aluno \n" + q);
			System.out.println(e.getMessage());
		}

		try {
			q = "CREATE TABLE Aluno ("
					+ "id INTEGER  PRIMARY KEY GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), "
					+ "numero INTEGER," + "nome VARCHAR(64)" + ")";
			st.execute(q);
		} catch (Exception e) {
			System.out.println();
			System.out.println(" Erro ao criar tabela Aluno \n" + q);
			System.out.println(e.getMessage());
		}
		try {
			q = "CREATE UNIQUE INDEX Aluno_id ON Aluno (id)";
			st.execute(q);
		} catch (Exception e) {
			System.out.println();
			System.out.println(" Erro ao criar �ndice tabela Aluno_id \n" + q);
			System.out.println(e.getMessage());
		}
		try {
			q = "CREATE INDEX Aluno_num ON Aluno (numero)";
			st.execute(q);
		} catch (Exception e) {
			System.out.println();
			System.out.println(" Erro ao criar �ndice tabela Aluno_num \n" + q);
			System.out.println(e.getMessage());
		}
		//
		// Turma
		//
		System.out.println("Cria��o da tabela Turma");
		try {
			q = "CREATE TABLE Turma ("
					+ "id INTEGER  PRIMARY KEY GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), "
					+ "numero INTEGER," + "nome VARCHAR(16)" + ")";
			st.execute(q);
			q = "CREATE UNIQUE INDEX Turma_id ON Turma (id)";
			st.execute(q);
			q = "CREATE INDEX Turma_num ON Turma (numero)";
			st.execute(q);
		} catch (Exception e) {
			System.out.println();
			System.out.println(" Erro ao criar tabela Turma \n" + q);
			System.out.println(e.getMessage());
		}
		//
		// AlunoTurma
		// tabela associativa para registar a rela��o n:m
		// os campos idAluno e idTurma s�o chaves externas, e define-se que ao apagar o registo respectivo,
		//   a opera��o deve prolongar-se nesta tabela, apagando os registos correspondente; por exemplo,
		//   ao apagar um aluno (ON DELETE), todos os registos que se referem a esse aluno nesta tabela s�o
		//   automaticamente (CASCADE) apagados
		//
		System.out.println("Cria��o da tabela AlunoTurma");
		try {
			q = "CREATE TABLE AlunoTurma ("
					+ "idAluno INTEGER REFERENCES Aluno(id) ON DELETE CASCADE,"
					+ "idTurma INTEGER REFERENCES Turma(id) ON DELETE CASCADE"
					+ ")";
			st.execute(q);
			q = "CREATE INDEX AlunoTurma_ia ON AlunoTurma (idAluno)";
			st.execute(q);
			q = "CREATE INDEX AlunoTurma_it ON AlunoTurma (idTurma)";
			st.execute(q);
		} catch (Exception e) {
			System.out.println();
			System.out.println(" Erro ao criar tabela AlunoTurma \n" + q);
			System.out.println(e.getMessage());
		}

		// DADOS
		try {
			q = "INSERT INTO Aluno " + "(numero,nome) " + "VALUES ("
					+ "1,'Manuel'" + ")";
			st.execute(q);
			q = "INSERT INTO Aluno " + "(numero,nome) " + "VALUES ("
					+ "2,'Maria'" + ")";
			st.execute(q);
			q = "INSERT INTO Aluno " + "(numero,nome) " + "VALUES ("
					+ "11,'Carlos'" + ")";
			st.execute(q);
			q = "INSERT INTO Aluno " + "(numero,nome) " + "VALUES ("
					+ "21,'Ana'" + ")";
			st.execute(q);
		} catch (Exception e) {
			System.out.println();
			System.out.println(" Erro ao criar valores Aluno \n" + q);
			System.out.println(e.getMessage());
		}
		try {
			q = "INSERT INTO Turma " + "(numero,nome) " + "VALUES (" + "1,'IA'"
					+ ")";
			st.execute(q);
			q = "INSERT INTO Turma " + "(numero,nome) " + "VALUES ("
					+ "11,'PAJ'" + ")";
			st.execute(q);
			q = "INSERT INTO Turma " + "(numero,nome) " + "VALUES ("
					+ "22,'ALG'" + ")";
			st.execute(q);
			q = "INSERT INTO Turma " + "(numero,nome) " + "VALUES ("
					+ "3,'FBD'" + ")";
			st.execute(q);
		} catch (Exception e) {
			System.out.println();
			System.out.println(" Erro ao criar valores Turma \n" + q);
			System.out.println(e.getMessage());
		}
		try {
			q = "INSERT INTO AlunoTurma " + "(idAluno,idTurma) " + "VALUES ("
					+ "1,1" + ")";
			st.execute(q);
			q = "INSERT INTO AlunoTurma " + "(idAluno,idTurma) " + "VALUES ("
					+ "1,3" + ")";
			st.execute(q);
			q = "INSERT INTO AlunoTurma " + "(idAluno,idTurma) " + "VALUES ("
					+ "2,1" + ")";
			st.execute(q);
			q = "INSERT INTO AlunoTurma " + "(idAluno,idTurma) " + "VALUES ("
					+ "2,2" + ")";
			st.execute(q);
			q = "INSERT INTO AlunoTurma " + "(idAluno,idTurma) " + "VALUES ("
					+ "3,1" + ")";
			st.execute(q);
			q = "INSERT INTO AlunoTurma " + "(idAluno,idTurma) " + "VALUES ("
					+ "3,2" + ")";
			st.execute(q);
			q = "INSERT INTO AlunoTurma " + "(idAluno,idTurma) " + "VALUES ("
					+ "3,4" + ")";
			st.execute(q);
			q = "INSERT INTO AlunoTurma " + "(idAluno,idTurma) " + "VALUES ("
					+ "4,2" + ")";
			st.execute(q);
		} catch (Exception e) {
			System.out.println();
			System.out.println(" Erro ao criar valores AlunoTurma \n" + q);
			System.out.println(e.getMessage());
		}
		System.out.println(" Fecho do statement \n");
		if (st != null) {
			try {
				st.close();
			} catch (Exception e) {
				System.out.println();
				System.out.println(" Erro ao fechar statement " + q);
				System.out.println(e.getMessage());
			}
		}
		LigacaoBD.close();
	}

	public Connection getConnection() {
		return derby;
	}

	public static void main(String[] args) {
		CriaBD c = new CriaBD();
		System.out.println("OK");
	}
}
