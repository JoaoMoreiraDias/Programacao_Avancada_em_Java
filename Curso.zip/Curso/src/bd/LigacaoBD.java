package bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class LigacaoBD {
	private static Connection derby;

	public static Connection getConnection() {
		if (derby == null)
			createConnection();
		return derby;
	}

	private static void createConnection() {
		String st = "";
		System.out.println("get connection");
		try {
			derby = null;
			Properties prop = new Properties();
			prop.put("user", "Curso");
			prop.put("password", "curso");
			prop.put("create", "true");
			st = "jdbc:derby:bd\\Curso";
			derby = DriverManager.getConnection(st, prop);

			System.out.println("connection OK");
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao criar a connection � base de dados ");
			System.exit( 0);
		}
	}

	public static void close() {
		try {
			derby.close();
		} catch (Exception ex) {
		}
		;
		derby = null;
	}
}
