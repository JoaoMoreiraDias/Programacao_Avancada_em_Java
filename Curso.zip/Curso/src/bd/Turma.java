package bd;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Turma {
	private int id;
	private int numero;
	private String nome;
	private static Connection derby = LigacaoBD.getConnection();

	public Turma() {
		id = 0;
		numero = 0;
		nome = "";
	}

	public Turma(int numero) {
		id = 0;
		this.numero = numero;
		nome = "";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	// retorna a turma com id=id
	public static Turma getTurma(int id) {
		Turma turma = null;
		String q;
		Statement st = null;
		ResultSet res = null;
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out
					.println(" Erro ao criar o 'statement' da base de dados ");
			return null;
		}
		q = "SELECT * FROM Turma WHERE id=" + id;
		try {
			res = st.executeQuery(q);
			if (res.next()) { // teve resposta ?
				turma = new Turma();
				turma.setId(res.getInt("id"));
				turma.setNumero(res.getInt("numero"));
				turma.setNome(res.getString("nome"));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao fazer query " + st);
			return null;
		} finally {
			if (res != null)
				try {
					res.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			if (st != null)
				try {
					st.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
		}
		return turma;
	}

	// retorna a turma com numero=numero
	public static Turma getTurmaNum(int numero) {
		Turma turma = null;
		String q;
		Statement st = null;
		ResultSet res = null;
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out
					.println(" Erro ao criar o 'statement' da base de dados ");
			return null;
		}
		q = "SELECT * FROM Turma WHERE numero=" + numero;
		try {
			res = st.executeQuery(q);
			if (res.next()) { // teve resposta ?
				turma = new Turma();
				turma.setId(res.getInt("id"));
				turma.setNumero(res.getInt("numero"));
				turma.setNome(res.getString("nome"));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao fazer query " + st);
			return null;
		} finally {
			if (res != null)
				try {
					res.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			if (st != null)
				try {
					st.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
		}
		return turma;
	}

	// retorna um ArrayList com todas as turmas
	public static ArrayList<Turma> getTurmas() {
		Turma turma = null;
		String q;
		Statement st = null;
		ResultSet res = null;
		ArrayList<Turma> turmas = new ArrayList<Turma>();
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out
					.println(" Erro ao criar o 'statement' da base de dados ");
			return null;
		}
		q = "SELECT * FROM Turma ORDER BY numero";
		try {
			res = st.executeQuery(q);
			while (res.next()) { // teve resposta ?
				turma = new Turma();
				try {
					turma.setId(res.getInt("id"));
					turma.setNumero(res.getInt("numero"));
					turma.setNome(res.getString("nome"));
					turmas.add(turma);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao fazer query " + st);
			return null;
		} finally {
			if (res != null)
				try {
					res.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			if (st != null)
				try {
					st.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
		}
		return turmas;
	}

	// retorna um ArrayList com todas as turmas do aluno com id idAluno
	public static ArrayList<Turma> getTurmas(int idAluno) {
		Turma turma = null;
		String q;
		Statement st = null;
		ResultSet res = null;
		ArrayList<Turma> turmas = new ArrayList<Turma>();
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out
					.println(" Erro ao criar o 'statement' da base de dados ");
			return null;
		}
		q = "SELECT * FROM AlunoTurma WHERE idAluno=" + idAluno;
		try {
			res = st.executeQuery(q);
			while (res.next()) { // teve resposta ?
				turma = Turma.getTurma(res.getInt("idTurma"));
				turmas.add(turma);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao fazer query " + st);
			return null;
		} finally {
			if (res != null)
				try {
					res.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			if (st != null)
				try {
					st.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
		}
		return turmas;
	}

	// define as turmas associadas ao aluno com id=idAluno
	public static void setTurmas(int idAluno, ArrayList<Turma> turmas) {
		String q;
		Statement st = null;
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out
					.println(" Erro ao criar o 'statement' da base de dados ");
			return;
		}
		q = "DELETE FROM AlunoTurma WHERE idAluno=" + idAluno; // apaga as
																// turmas do
																// aluno
		try {
			st.execute(q);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao fazer query " + st);
			return;
		} finally {
			if (st != null)
				try {
					st.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
		}
		for (Turma t : turmas) { // insere cada uma das turmas do aluno
			insereTurma(idAluno, t);
		}
	}

	// associa a turma t ao aluno com id=idAluno
	private static void insereTurma(int idAluno, Turma t) {
		boolean jaExiste = false;
		String q;
		Statement st = null;
		ResultSet res = null;
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out
					.println(" Erro ao criar o 'statement' da base de dados ");
			return;
		}
		q = "SELECT * FROM AlunoTurma WHERE idAluno=" + idAluno
				+ " AND idTurma=" + t.getId();
		try {
			res = st.executeQuery(q);
			if (res.next()) { // teve resposta ?
				jaExiste = true;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao fazer query " + st);
			return;
		} finally {
			if (res != null)
				try {
					res.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			if (st != null)
				try {
					st.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
		}
		if (jaExiste) { // turma j� est� associada a este aluno, n�o duplica
			return;
		}
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out
					.println(" Erro ao criar o 'statement' da base de dados ");
			return;
		}
		// insere o par aluno/turma na tabela associativa
		q = "INSERT INTO AlunoTurma (idAluno,idTurma) VALUES (" + idAluno + ","
				+ t.getId() + ")";
		try {
			st.execute(q);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao fazer query " + st);
			return;
		} finally {
			if (st != null)
				try {
					st.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
		}
	}

	public String toString() {
		String st = "Turma id=" + id + "  num=" + numero + "  nome=" + nome
				+ "\n";
		return st;
	}

}
