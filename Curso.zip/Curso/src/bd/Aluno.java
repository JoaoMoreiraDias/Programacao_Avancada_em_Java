package bd;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Aluno {
	private int id;
	private int numero;
	private String nome;
	private ArrayList<Turma> turmas;
	private static Connection derby = LigacaoBD.getConnection();

	public Aluno() {
		id = 0;
		numero = 0;
		nome = "";
		turmas = new ArrayList<Turma>();
	}

	public Aluno(int numero) {
		id = 0;
		this.numero = numero;
		nome = "";
		turmas = new ArrayList<Turma>();
	}

	// retorna o aluno com id=id
	public static Aluno getAlunoId(int id) {
		Aluno aluno = null;
		String q;
		Statement st = null;
		ResultSet res = null;
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out
					.println(" Erro ao criar o 'statement' da base de dados ");
			return null;
		}
		q = "SELECT * FROM Aluno WHERE id=" + id;
		try {
			res = st.executeQuery(q);
			if (res.next()) { // teve resposta ?
				aluno = new Aluno();
				aluno.setId(res.getInt("id"));
				aluno.setNumero(res.getInt("numero"));
				aluno.setNome(res.getString("nome"));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao fazer query " + st);
			return null;
		} finally {
			if (res!=null)
				try {
					res.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			if (st!=null)
				try {
					st.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
		}
		if (aluno != null)
			aluno.setTurmas(Turma.getTurmas(aluno.getId()));
		return aluno;
	}

	// retorna aluno com numero=numero
	public static Aluno getAlunoNum(int numero) {
		Aluno aluno = null;
		String q;
		Statement st = null;
		ResultSet res = null;
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out
					.println(" Erro ao criar o 'statement' da base de dados ");
			return null;
		}
		q = "SELECT * FROM Aluno WHERE id=" + numero;
		try {
			res = st.executeQuery(q);
			if (res.next()) { // teve resposta ?
				aluno = new Aluno();
				aluno.setId(res.getInt("id"));
				aluno.setNumero(res.getInt("numero"));
				aluno.setNome(res.getString("nome"));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao fazer query " + st);
			return null;
		} finally {
			if (res!=null)
				try {
					res.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			if (st!=null)
				try {
					st.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
		}
		if (aluno != null)
			aluno.setTurmas(Turma.getTurmas(aluno.getId()));
		return aluno;
	}

	// retorna ArrayList com todos os alunos
	public static ArrayList<Aluno> getAlunos() {
		Aluno aluno = null;
		String q;
		Statement st = null;
		ResultSet res = null;
		ArrayList<Aluno> alunos = new ArrayList<Aluno>();
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out
					.println(" Erro ao criar o 'statement' da base de dados ");
			return alunos; // vazio
		}
		q = "SELECT * FROM Aluno ORDER BY numero";
		try {
			res = st.executeQuery(q);
			while (res.next()) { // teve resposta ?
				aluno = new Aluno();
				try {
					aluno.setId(res.getInt("id"));
					aluno.setNumero(res.getInt("numero"));
					aluno.setNome(res.getString("nome"));
					alunos.add( aluno);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao fazer query " + st);
		} finally {
			if (res!=null)
				try {
					res.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			if (st!=null)
				try {
					st.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
		}
		for (Aluno al : alunos)
			al.setTurmas(Turma.getTurmas(al.getId()));
		return alunos;
	}

	// grava este aluno
	public boolean grava() {
		String q;
		Statement st = null;
		ResultSet res = null;
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out
					.println(" Erro ao criar o 'statement' da base de dados ");
			return false; // falhou
		}
		if (id == 0) { // aluno novo, ainda n�o tem id
			try {
				q = "INSERT INTO Aluno (numero,nome) VALUES ("+numero+",'"+nome+"')";
				st.execute(q);
				q = "SELECT * FROM Aluno WHERE numero=" + numero;
				res = st.executeQuery(q);
				if (res.next()) { // teve resposta ?
					setId(res.getInt("id")); // define o id do objecto, definido pela BD
				}
			} catch (Exception ex) {
				ex.printStackTrace();
				System.out.println();
				System.out.println(" Erro ao fazer query " + st);
				return false; // falhou
			} finally {
				if (res!=null)
					try {
						res.close();
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				if (st!=null)
					try {
						st.close();
					} catch (Exception ex) {
						ex.printStackTrace();
					}
			}
		} else { // o objecto j� tem id, � uma altera��o de dados; a refer�ncia � o id; tudo o resto pode mudar
			q = "UPDATE Aluno SET " + "numero=" + numero + ", "
					+ "nome='" + nome + "' "
					+ "WHERE id="+id;
			try {
				st.execute(q);
			} catch (Exception ex) {
				ex.printStackTrace();
				System.out.println();
				System.out.println(" Erro ao fazer query " + st);
				return false;
			} finally {
				if (st!=null)
					try {
						st.close();
					} catch (Exception ex) {
						ex.printStackTrace();
					}
			}
		}
		Turma.setTurmas( id, turmas); // actualiza as turmas; tamb�m podem ter mudado
		return true; // altera��o feita
	}
	
	public void juntaTurma( Turma t) {
		for (Turma ut : turmas) {
			if (ut.getNumero() == t.getNumero())
				return;	// j� existe
		}
		turmas.add( t);
	}
	
	// apaga turma da lista de turmas deste aluno
	public void apagaTurma( Turma t) {
		Turma ta = null;	// turma a apagar
		for (Turma ut : turmas) {
			if (ut.getNumero() == t.getNumero()) {
				ta = ut;	// � este o objecto da turma a apagar
				break;
			}
		}
		if (ta != null)  // encontrou a turma? Se sim, apaga
			turmas.remove(ta); // o par�metro tem que ser O objecto a apagar e n�o apenas um igual
	}

	// apaga aluno
	// contamos com CASCADE DELETE na defini��o das tabelas para automaticamente apagar os registos das turmas da tabela associativa
	// ver criaBD, cria��o da tabela AlunoTurma
	public void apaga() {
		String q;
		Statement st = null;
		try {
			st = derby.createStatement(); // cria statement
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out
					.println(" Erro ao criar o 'statement' da base de dados ");
			return;
		}
		q = "DELETE FROM Aluno WHERE id=" + id;
		try {
			st.execute(q);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println();
			System.out.println(" Erro ao fazer query " + st);
			return;
		} finally {
			if (st!=null)
				try {
					st.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
		}
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public ArrayList<Turma> getTurmas() {
		return turmas;
	}

	public void setTurmas(ArrayList<Turma> turmas) {
		this.turmas = turmas;
	}

	public String toString() {
		String st = "Aluno id="+id+"  num="+numero+"  nome="+nome+"\n";
		for (Turma t : turmas) {
			st += "  "+t;
		}
		return st;
	}
}
